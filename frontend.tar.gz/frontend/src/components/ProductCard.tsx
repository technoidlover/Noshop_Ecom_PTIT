'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Product } from '@/types';
import { formatPrice } from '@/lib/api';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/context/ToastContext';
import { Star, ShoppingCart, Truck, ShieldCheck } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { showToast } = useToast();

  const discountPercent =
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null;

  const imageUrl =
    product.images && product.images.length > 0
      ? product.images[0]
      : 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80';

  const shopCity =
    typeof product.seller === 'object' && product.seller?.shop?.address
      ? product.seller.shop.address.split(',').pop()?.trim() || 'Hà Nội'
      : 'Hà Nội';

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    if (product.stock > 0) {
      addToCart(product, 1);
      showToast(`Đã thêm "${product.name.slice(0, 30)}..." vào giỏ hàng!`, 'success');
    }
  };

  return (
    <div className="group bg-white rounded-xl border border-gray-200/70 overflow-hidden hover:shadow-xl hover:border-blue-400/80 transition-all duration-300 flex flex-col justify-between relative hover:-translate-y-1">
      <div>
        {/* Thumbnail & Badges */}
        <Link href={`/products/${product._id}`} className="block relative aspect-square overflow-hidden bg-gray-50">
          <Image
            src={imageUrl}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
            className="object-cover group-hover:scale-105 transition-transform duration-500"
          />

          {/* Shopee Mall red badge */}
          <div className="absolute top-2 left-2 flex flex-col space-y-1">
            <span className="bg-red-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-xs uppercase tracking-wider">
              Mall
            </span>
            <span className="bg-emerald-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs flex items-center gap-0.5">
              <Truck className="w-2.5 h-2.5" /> Freeship
            </span>
          </div>

          {/* Yellow Shopee Discount Tag */}
          {discountPercent && (
            <div className="absolute top-0 right-2 bg-amber-400 text-red-600 text-center px-1.5 py-1 rounded-b-md shadow-xs font-black">
              <span className="block text-[10px] leading-tight">-{discountPercent}%</span>
              <span className="block text-[8px] uppercase text-slate-800 font-bold leading-tight">GIẢM</span>
            </div>
          )}

          {/* Out of Stock Overlay */}
          {product.stock <= 0 && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center">
              <span className="bg-slate-900/90 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider border border-white/20">
                Hết Hàng
              </span>
            </div>
          )}
        </Link>

        {/* Content Details */}
        <div className="p-3">
          <Link href={`/products/${product._id}`}>
            <h3 className="text-xs sm:text-sm font-medium text-gray-800 group-hover:text-blue-600 transition-colors line-clamp-2 min-h-[36px] sm:min-h-[40px] leading-snug">
              <span className="inline-block px-1 py-0.2 mr-1 text-[9px] font-bold text-red-600 border border-red-500 rounded bg-red-50">
                Chính Hãng
              </span>
              {product.name}
            </h3>
          </Link>

          {/* Price Block */}
          <div className="mt-2.5 flex items-baseline space-x-1.5">
            <span className="text-sm sm:text-base font-black text-red-600">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-[11px] text-gray-400 line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          {/* Rating & Sold Progress */}
          <div className="flex items-center justify-between text-[11px] mt-2 text-gray-500">
            <div className="flex items-center text-amber-500">
              <Star className="w-3 h-3 fill-current" />
              <span className="text-[11px] font-bold text-gray-700 ml-0.5">{product.rating}</span>
            </div>
            <span className="text-gray-400">Đã bán {product.sold > 1000 ? `${(product.sold / 1000).toFixed(1)}k` : product.sold}</span>
          </div>
        </div>
      </div>

      {/* Card Footer: City and Fast Add Cart Button */}
      <div className="px-3 pb-3 pt-1 border-t border-gray-100 flex items-center justify-between">
        <span className="text-[10px] text-gray-400 truncate max-w-[110px]">
          {shopCity}
        </span>

        <button
          onClick={handleAdd}
          disabled={product.stock <= 0}
          className="p-2 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition shadow-xs disabled:opacity-40 disabled:pointer-events-none"
          title="Thêm vào giỏ"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
