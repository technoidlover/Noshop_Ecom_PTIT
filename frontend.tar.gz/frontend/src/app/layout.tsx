import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from '@/context/AuthContext';
import { CartProvider } from '@/context/CartContext';
import { ToastProvider } from '@/context/ToastContext';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';

export const metadata: Metadata = {
  title: 'MinhTech E-Commerce | Sàn Thương Mại Điện Tử Hàng Đầu',
  description: 'Sàn thương mại điện tử công nghệ và đời sống hàng đầu Việt Nam. Mua sắm an tâm, bảo đảm chính hãng 100%, freeship toàn quốc.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className="bg-[#f5f5fa] text-slate-900 min-h-screen flex flex-col font-sans selection:bg-red-500 selection:text-white">
        <AuthProvider>
          <CartProvider>
            <ToastProvider>
              <Navbar />
              <main className="flex-1">
                {children}
              </main>
              <Footer />
            </ToastProvider>
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
